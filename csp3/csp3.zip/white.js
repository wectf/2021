document.querySelectorAll("h1").forEach(v => v.style.color = "black")
document.querySelectorAll("p").forEach(v => v.style.color = "black")
document.querySelectorAll("html").forEach(v => v.style.background = "white")
