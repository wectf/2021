import redis

redis_instance = redis.Redis()
